// ---------------------------------------------------------------------------
// rendering_registry.js
// Mirrors dsp_registry.js's shape: RENDER_ALGORITHMS holds the actual
// drawing code (reuses our real renderWaveformSweep/buildChartLayout, not
// rewritten). createRenderingEngine() wraps it with the methods the
// dispatcher needs.
//
// durationMs is passed in fully pre-computed by journey_interpreter.js
// (baseDurationMs already divided by the current speed) -- these renderers
// never do their own speed math, so there's exactly one place that logic
// can live, not two independently-maintained copies.
//
// Depends on shared_signal_utils.js (renderWaveformSweep, buildChartLayout)
// -- must load before this file.
// ---------------------------------------------------------------------------

const RENDER_ALGORITHMS = {
    chart_v1: {
        render(container, dspOutput, config, sampleId, fs, durationMs) {
            container.innerHTML = ""; // Plotly.newPlot doesn't clear pre-existing HTML (e.g. dwt_comparison_view's toggle buttons from a previous stage) -- without this, they'd linger alongside the new plot
            const { filteredSignal, peakIndices } = dspOutput.finalOutput;
            const t = filteredSignal.map((_, i) => i / fs); // real seconds, not raw sample index
            // durationMs already includes speed scaling AND any per-stage
            // baseDurationMs override -- computed ONCE, in
            // journey_interpreter.js, so this renderer, the auto-advance
            // timer, and the progress bar can never disagree about how
            // long this stage actually takes.

            renderWaveformSweep(container, sampleId, durationMs, t, filteredSignal, fs);

            // Peak markers overlaid separately -- renderWaveformSweep only
            // draws the line trace; keeping this simple for the one-stage
            // proof rather than modifying that shared function's signature.
            setTimeout(() => {
                Plotly.addTraces(container, {
                    x: peakIndices.map(i => i / fs), y: peakIndices.map(i => filteredSignal[i]),
                    mode: "markers",
                    marker: { color: config.peakMarkerColor || "#ff4d4d", size: 8 },
                });
            }, 50);
        },
    },
    scatter_density: {
        // Progressively reveals dots over time, same as the original
        // hrvMetricsRenderer -- static instant population was a
        // simplification made for the proof, not an intentional change.
        render(container, dspOutput, config, sampleId, fs, durationMs) {
            container.innerHTML = ""; // same fix as chart_v1 -- guards against leftover HTML from a previous stage's renderer
            const { rrCurrent, rrNext, sd1, sd2 } = dspOutput.finalOutput;
            const axisMax = Math.max(...rrCurrent, ...rrNext) * 1.15;

            const identityLine = {
                x: [0, axisMax], y: [0, axisMax], mode: "lines",
                line: { color: "rgba(150,150,150,0.4)", width: 1, dash: "dash" },
                showlegend: false, hoverinfo: "skip",
            };
            const points = {
                x: [], y: [], mode: "markers",
                marker: { color: "#00E5FF", size: 6, opacity: 0.75 },
                showlegend: false, hoverinfo: "skip",
            };

            const layout = {
                paper_bgcolor: "transparent", plot_bgcolor: "transparent",
                margin: { t: 10, r: 10, b: 40, l: 50 },
                xaxis: { title: "RR[n] (ms)", range: [0, axisMax], color: "#888", tickfont: { size: 13 }, titlefont: { size: 14 } },
                yaxis: { title: "RR[n+1] (ms)", range: [0, axisMax], color: "#888", scaleanchor: "x", tickfont: { size: 13 }, titlefont: { size: 14 } },
                annotations: [{
                    text: `SD1: ${sd1.toFixed(0)}ms &nbsp; SD2: ${sd2.toFixed(0)}ms`,
                    xref: "paper", yref: "paper", x: 0.02, y: 0.98,
                    showarrow: false, font: { color: "#fff", size: 14 },
                }],
            };

            Plotly.newPlot(container, [identityLine, points], layout, { staticPlot: true, responsive: true });

            // durationMs already speed-scaled, same reasoning as chart_v1
            function drawAtElapsed(elapsed) {
                const progress = Math.min(1, elapsed / durationMs);
                const visibleCount = Math.max(1, Math.round(progress * rrCurrent.length));
                Plotly.update(container, { x: [null, rrCurrent.slice(0, visibleCount)], y: [null, rrNext.slice(0, visibleCount)] }, {});
            }
            startSweepLoop(sampleId, durationMs, drawAtElapsed);
        },
    },
    dwt_comparison_view: {
        // Multi-select toggle stack -- reuses the exact pattern (and the
        // exact downsampling fix) already proven in the earlier
        // standalone DWT journey: toggling several levels on
        // simultaneously without downsampling caused a real freeze there.
        // Same fix, same reasoning, applied here.
        render(container, dspOutput) {
            const { decomposition, originalSignal } = dspOutput.finalOutput;

            const finalLevel = decomposition[decomposition.length - 1];
            const allOptions = [
                { id: "original", label: "Original", data: originalSignal },
                ...decomposition.map(d => ({ id: `d${d.level}`, label: `D${d.level}`, data: d.detail })),
                { id: `a${finalLevel.level}`, label: `A${finalLevel.level}`, data: finalLevel.approx },
            ];

            container.innerHTML = `<div class="dwt-stack-container"></div><div class="dwt-toggle-row" style="display:flex; gap:6px; padding:8px; flex-wrap:wrap;"></div>`;
            const stackContainer = container.querySelector(".dwt-stack-container");
            const toggleRow = container.querySelector(".dwt-toggle-row");
            stackContainer.addEventListener("click", e => e.stopPropagation());

            const MAX_POINTS = 600;
            function downsample(data) {
                if (data.length <= MAX_POINTS) return data.map((v, i) => [i, v]);
                const stride = Math.ceil(data.length / MAX_POINTS);
                const points = [];
                for (let i = 0; i < data.length; i += stride) points.push([i, data[i]]);
                const lastIdx = data.length - 1;
                if (points[points.length - 1][0] !== lastIdx) points.push([lastIdx, data[lastIdx]]);
                return points;
            }

            const activeIds = new Set(["original"]);

            function renderStack() {
                stackContainer.innerHTML = "";
                allOptions.filter(opt => activeIds.has(opt.id)).forEach(opt => {
                    const points = downsample(opt.data);
                    const item = document.createElement("div");
                    item.style.cssText = "background:#16161A; border-radius:8px; margin:6px; padding:4px;";
                    item.innerHTML = `<div style="font-size:0.85rem; color:#aaa; padding:2px 6px;">${opt.label}</div><div style="height:120px;"></div>`;
                    stackContainer.appendChild(item);
                    const chartDiv = item.querySelector("div:last-child");
                    Plotly.newPlot(chartDiv, [{
                        x: points.map(p => p[0]), y: points.map(p => p[1]), mode: "lines",
                        line: { color: "#00FF66", width: 1.2 }, hoverinfo: "skip",
                    }], {
                        paper_bgcolor: "transparent", plot_bgcolor: "transparent",
                        margin: { t: 4, r: 6, b: 20, l: 34 },
                    }, { staticPlot: true, responsive: true });
                });
            }

            allOptions.forEach(opt => {
                const btn = document.createElement("button");
                btn.textContent = opt.label;
                btn.className = "rail-btn";
                btn.classList.toggle("active", activeIds.has(opt.id));
                btn.addEventListener("click", (e) => {
                    e.stopPropagation(); // without this, toggling a level would also bubble up and trigger the card's tap-zone navigation
                    activeIds.has(opt.id) ? activeIds.delete(opt.id) : activeIds.add(opt.id);
                    btn.classList.toggle("active", activeIds.has(opt.id));
                    renderStack();
                });
                toggleRow.appendChild(btn);
            });

            renderStack();
        },
    },
};

function createRenderingEngine(config) {
    let activeId = config.availableRenderers.find(r => r.isDefault).id;
    let renderConfig = { ...config.config };

    return {
        render(container, dspOutput, sampleId, fs, durationMs) {
            const renderer = RENDER_ALGORITHMS[activeId];
            if (!renderer) {
                console.error(`Rendering registry: no renderer registered for "${activeId}"`);
                return;
            }
            renderer.render(container, dspOutput, renderConfig, sampleId, fs, durationMs);
        },
        getParameter(key) {
            return renderConfig[key];
        },
        setParameter(payload) {
            if (payload.operation === "toggle") {
                renderConfig[payload.key] = !renderConfig[payload.key];
            } else {
                renderConfig[payload.key] = payload.value;
            }
        },
        toggleConfigFlag(payload) {
            renderConfig[payload.key] = !renderConfig[payload.key];
        },
        getActiveRenderer() {
            return activeId;
        },
        switchRenderer() {
            const ids = config.availableRenderers.map(r => r.id);
            const currentIdx = ids.indexOf(activeId);
            activeId = ids[(currentIdx + 1) % ids.length];
        },
        applyTheme(theme) {
            renderConfig.signalColor = theme.palette.primary;
            renderConfig.peakMarkerColor = theme.palette.accent;
        },
    };
}