// ---------------------------------------------------------------------------
// dsp_registry.js
// Two layers: DSP_ALGORITHMS holds the actual math, keyed by id (reuses
// our real, already-tested panTompkinsDetectPeaks and
// hamiltonTompkinsDetectPeaks -- not rewritten). createDspEngine() wraps
// whichever algorithms a stage's recipe lists, exposing exactly the
// methods the dispatcher can call: getParameter/setParameter,
// getActiveAlgorithm/switchAlgorithm, plus process().
//
// Depends on pan_tompkins_filter.js (panTompkinsDetectPeaks),
// hamilton_tompkins_filter.js (hamiltonTompkinsDetectPeaks), and
// db4_filter.js (multiLevelDb4DWT) -- all three must load before this file.
// ---------------------------------------------------------------------------

const DSP_ALGORITHMS = {
    pan_tompkins: {
        process(data, parameters) {
            const y = parameters.invertSignal ? data.y.map(v => -v) : data.y;
            const { peakIndices, steps } = panTompkinsDetectPeaks(y, data.fs);
            const rrIntervalsMs = [];
            for (let i = 1; i < peakIndices.length; i++) {
                rrIntervalsMs.push(((peakIndices[i] - peakIndices[i - 1]) / data.fs) * 1000);
            }
            return {
                interimOutputs: steps,
                finalOutput: { filteredSignal: y, peakIndices, rrIntervalsMs },
            };
        },
    },
    hamilton_tompkins: {
        process(data, parameters) {
            const y = parameters.invertSignal ? data.y.map(v => -v) : data.y;
            const { peakIndices, steps } = hamiltonTompkinsDetectPeaks(y, data.fs);
            const rrIntervalsMs = [];
            for (let i = 1; i < peakIndices.length; i++) {
                rrIntervalsMs.push(((peakIndices[i] - peakIndices[i - 1]) / data.fs) * 1000);
            }
            return {
                interimOutputs: steps,
                finalOutput: { filteredSignal: y, peakIndices, rrIntervalsMs },
            };
        },
    },
    poincare_standard: {
        // data here is NOT {t,y,fs} -- it's whatever the journey interpreter
        // resolved from dataSource, which for this stage is Stage 1's
        // rrIntervalsMs array directly (PREVIOUS_STAGE_PIPELINE).
        process(rrIntervalsMs, parameters) {
            const rrCurrent = rrIntervalsMs.slice(0, -1);
            const rrNext = rrIntervalsMs.slice(1);

            const diffs = rrCurrent.map((v, i) => v - rrNext[i]);
            const mean = arr => arr.reduce((a, b) => a + b, 0) / arr.length;
            const variance = arr => {
                const m = mean(arr);
                return mean(arr.map(v => (v - m) ** 2));
            };

            // Standard Poincare formulas -- SD1 = short-term variability
            // (perpendicular to the identity line), SD2 = long-term.
            const sd1 = Math.sqrt(0.5 * variance(diffs));
            const sd2 = Math.sqrt(2 * variance(rrCurrent) - sd1 * sd1);

            return {
                interimOutputs: [],
                finalOutput: { rrCurrent, rrNext, sd1, sd2 },
            };
        },
    },
    db4_wavelet: {
        // data here is {t, y, fs} -- same shape raw_signal/HTTP_REST produces.
        process(data, parameters) {
            const levels = parameters.levels || 6;
            const decomposition = multiLevelDb4DWT(data.y, levels);
            return {
                interimOutputs: [],
                finalOutput: { decomposition, originalSignal: data.y },
            };
        },
    },
    passthrough: {
        // For stages that just want to DISPLAY the raw signal via
        // chart_v1, with no actual DSP happening -- reusing pan_tompkins
        // for this would misleadingly imply peak detection is running
        // when the journey doesn't care about peaks at all.
        process(data) {
            return {
                interimOutputs: [],
                finalOutput: { filteredSignal: data.y, peakIndices: [] },
            };
        },
    },
};

function createDspEngine(config) {
    // config = the recipe's "dspEngine" object
    let activeId = config.availableAlgorithms.find(a => a.isDefault).id;
    let parameters = { ...config.parameters };

    return {
        process(data) {
            const algo = DSP_ALGORITHMS[activeId];
            if (!algo) {
                console.error(`DSP registry: no algorithm registered for "${activeId}"`);
                return null;
            }
            return algo.process(data, parameters);
        },
        getParameter(key) {
            return parameters[key];
        },
        setParameter(payload) {
            // matches the recipe's {"key": "invertSignal", "operation": "toggle"} shape
            if (payload.operation === "toggle") {
                parameters[payload.key] = !parameters[payload.key];
            } else {
                parameters[payload.key] = payload.value;
            }
        },
        getActiveAlgorithm() {
            return activeId;
        },
        switchAlgorithm() {
            const ids = config.availableAlgorithms.map(a => a.id);
            const currentIdx = ids.indexOf(activeId);
            activeId = ids[(currentIdx + 1) % ids.length];
        },
    };
}
