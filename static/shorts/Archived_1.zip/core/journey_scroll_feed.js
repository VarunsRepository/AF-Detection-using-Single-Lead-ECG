// ---------------------------------------------------------------------------
// journey_scroll_feed.js
// The real scrolling feed for the NEW dispatcher/registry/interpreter
// system -- distinct from core/journey_feed.js, which drives the OLDER
// registerStage-based pipeline still used by shorts_feed.html/dwt_journey.html.
// This one builds one card per real sample, calls interpretJourney() per
// card (lazy-started only when it scrolls into view), and cancels
// animations for cards that scroll out of view.
//
// Each card gets its OWN title/caption/chart/rail elements, scoped via
// class selectors WITHIN that card -- not global IDs, which would collide
// the instant more than one card exists on screen (the exact bug
// interpretJourney()'s title/caption parameters were just fixed to avoid).
//
// Depends on core/journey_interpreter.js (interpretJourney) and
// core/shared_signal_utils.js (cancelSweepAnimation) -- both must load
// before this file.
// ---------------------------------------------------------------------------

// Matches the CURRENT, existing layout exactly -- if a recipe has no
// "layout" field at all, behavior is byte-for-byte identical to before
// this feature existed. Only recipes that EXPLICITLY set "layout" get
// anything different.
const DEFAULT_LAYOUT = {
    title: "top",
    caption: "top",
    description: "top",
    plot: "center",
    railControls: "bottom",
};

async function startJourneyScrollFeed({ apiEndpoint, journeyJson, feedContainer }) {
    const PAGE_SIZE = 5;
    let loadedCount = 0;
    let totalAvailable = null;
    let isLoadingMore = false;

    const activeJourneys = new Map();
    const cardElements = new Map();

    async function fetchSamplesPage(offset) {
        const res = await fetch(`${apiEndpoint}?limit=${PAGE_SIZE}&offset=${offset}`);
        if (!res.ok) throw new Error(`Server returned ${res.status}`);
        return res.json();
    }

    function buildCard(sampleId) {
        const layout = { ...DEFAULT_LAYOUT, ...(journeyJson.layout || {}) };

        const card = document.createElement("section");
        card.className = "journey-card";
        card.dataset.sampleId = sampleId;
        card.innerHTML = `
            <div class="stage-bar"></div>
            <div class="layout-zone" data-zone="top"></div>
            <div class="layout-zone" data-zone="center"></div>
            <div class="layout-zone" data-zone="bottom"></div>
            <div class="stage-rail"></div>
        `;

        // Content elements created standalone, THEN placed into whichever
        // zone the layout config names -- journey_interpreter.js never
        // needs to know or care where any of these physically ended up,
        // it just receives references to them, same as before.
        const titleEl = document.createElement("h2");
        titleEl.className = "stage-title";
        titleEl.textContent = "Loading...";

        const captionEl = document.createElement("p");
        captionEl.className = "stage-caption";

        const descriptionEl = document.createElement("p");
        descriptionEl.className = "stage-description";

        const chartEl = document.createElement("div");
        chartEl.className = "chart";

        // Fixed relative order within any zone that ends up sharing
        // multiple elements -- avoids ambiguity about which stacks above
        // which.
        [
            [titleEl, layout.title],
            [captionEl, layout.caption],
            [descriptionEl, layout.description],
            [chartEl, layout.plot],
        ].forEach(([el, zone]) => {
            const zoneEl = card.querySelector(`.layout-zone[data-zone="${zone}"]`);
            (zoneEl || card.querySelector('.layout-zone[data-zone="top"]')).appendChild(el);
        });

        const railEl = card.querySelector(".stage-rail");
        railEl.dataset.zone = layout.railControls;

        cardElements.set(sampleId, {
            titleEl, captionEl, descriptionEl, chartEl, railEl,
            progressBarEl: card.querySelector(".stage-bar"),
        });

        // Tap zones -- left third = restart-current-or-previous (see
        // below), right third = next, CENTER third = pause/resume.
        // Scoped to the WHOLE CARD, not just .chart -- tapping the
        // title/caption/description areas, or any empty space, should
        // navigate too, matching how Shorts/Reels make the entire screen
        // tappable. This means .stage-rail is a DESCENDANT of this
        // listener, so an explicit guard is needed: without it, tapping
        // a rail button would ALSO trigger navigation underneath it.
        // DWT's toggle buttons still work correctly via their own
        // existing stopPropagation() (rendering_registry.js) -- that
        // protection doesn't depend on where THIS listener is attached.
        const CENTER_ZONE_FRACTION = 0.34; // matches the main app's own tap-zone convention

        // Restart-vs-previous: matches Instagram Stories/TikTok's own
        // left-tap behavior. First left tap replays the CURRENT stage;
        // a second left tap, fast enough, actually goes to the previous
        // one. 350ms sits centered in the standard 300-500ms double-tap
        // detection window used across iOS/Android/desktop conventions --
        // grounded in typical human motor-response timing for
        // distinguishing an intentional rapid double-tap from two
        // separate, deliberate single taps.
        //
        // one instance per card, so each card's double-tap timing is
        // naturally independent of the others, not shared/confused
        // across different samples.
        const DOUBLE_TAP_THRESHOLD_MS = 350;
        let lastLeftTapTime = 0;

        card.addEventListener("click", (e) => {
            if (e.target.closest(".stage-rail")) return; // rail buttons handle their own clicks; don't ALSO navigate underneath them
            const journey = activeJourneys.get(sampleId);
            if (!journey) return;
            const rect = card.getBoundingClientRect();
            const relativeX = (e.clientX - rect.left) / rect.width;
            const centerStart = 0.5 - CENTER_ZONE_FRACTION / 2;
            const centerEnd = 0.5 + CENTER_ZONE_FRACTION / 2;

            if (relativeX >= centerStart && relativeX <= centerEnd) {
                journey.togglePause();
            } else if (relativeX > centerEnd) {
                journey.next();
            } else {
                const now = Date.now();
                if (now - lastLeftTapTime < DOUBLE_TAP_THRESHOLD_MS) {
                    journey.prev(); // fast second tap -- genuinely go back
                } else {
                    journey.restart(); // first tap (or a slow, separate one) -- just replay the current stage
                }
                lastLeftTapTime = now;
            }
        });

        return card;
    }

    const cardObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            const sampleId = entry.target.dataset.sampleId;
            if (entry.isIntersecting) {
                if (!activeJourneys.has(sampleId)) {
                    // Lazy-start -- the journey interpreter for this card
                    // is only ever built the FIRST time it scrolls into
                    // view, not upfront for every card on the page.
                    const els = cardElements.get(sampleId);
                    const journey = interpretJourney(journeyJson, sampleId, els.chartEl, els.railEl, els.titleEl, els.captionEl, els.progressBarEl, els.descriptionEl);
                    activeJourneys.set(sampleId, journey);
                    journey.start();
                }
            } else {
                cancelSweepAnimation(sampleId); // stop animating cards that have scrolled off-screen
            }
        });
    }, { threshold: 0.6 });

    async function loadFeedCards() {
        try {
            const { samples, total } = await fetchSamplesPage(0);
            totalAvailable = total;

            if (samples.length === 0) {
                feedContainer.innerHTML = '<p style="color:#747d8c;text-align:center;margin-top:40vh;">No records found.</p>';
                return;
            }

            samples.forEach(({ record_id }) => {
                const card = buildCard(record_id);
                feedContainer.appendChild(card);
                cardObserver.observe(card);
            });
            loadedCount = samples.length;
        } catch (err) {
            console.error("Failed to load sample list:", err);
            feedContainer.innerHTML = '<p style="color:#a32638;text-align:center;margin-top:40vh;">Could not load records.</p>';
        }
    }

    async function loadMoreCards(sentinel) {
        if (isLoadingMore) return;
        if (totalAvailable !== null && loadedCount >= totalAvailable) return;

        isLoadingMore = true;
        try {
            const { samples } = await fetchSamplesPage(loadedCount);
            samples.forEach(({ record_id }) => {
                const card = buildCard(record_id);
                feedContainer.insertBefore(card, sentinel);
                cardObserver.observe(card);
            });
            loadedCount += samples.length;
        } catch (err) {
            console.error("Failed to load more samples:", err);
        } finally {
            isLoadingMore = false;
        }
    }

    await loadFeedCards();

    const sentinel = document.createElement("div");
    sentinel.style.height = "1px";
    feedContainer.appendChild(sentinel);

    const sentinelObserver = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) loadMoreCards(sentinel);
    }, { threshold: 0.01 });
    sentinelObserver.observe(sentinel);
}