// ---------------------------------------------------------------------------
// journey_interpreter.js
// Extends the single-stage proof (stage_interpreter.js) to a real,
// multi-stage journey: resolves PREVIOUS_STAGE_PIPELINE data sources
// (Stage 2 consuming Stage 1's real rrIntervalsMs, not synthetic data),
// applies globalThemes across every stage, and provides the "journey"
// dispatch target (cycleSpeed) that stage-level buttons can target.
//
// Also implements journeyRules.autoAdvance (auto-moves to the next stage,
// cancelled cleanly if the user navigates manually first),
// journeyRules.preloadNextStage (background DSP warming), a real visual
// progress bar (uiShell.showProgressBar), and real pause/resume
// (playbackConfig.isPaused).
//
// Speed is now GENUINELY GLOBAL -- GLOBAL_SPEED_OPTIONS/globalSpeedIndex
// live at MODULE level, not inside this function, so every card in a
// scrolling feed shares the SAME speed state instead of each getting its
// own independent one reset to 1.0x. speedOptions itself is intentionally
// NOT recipe-configurable: if different recipes could define different
// option arrays while speedIndex stayed shared, the same index position
// would silently mean a different speed depending which card you're on.
//
// Depends on dsp_registry.js, rendering_registry.js, dispatcher.js, and
// shared_signal_utils.js (fetchSignal, activeSweepControl, startSweepLoop,
// cancelSweepAnimation) -- all must load before this file.
// ---------------------------------------------------------------------------

const STAGE_DURATION_MS = 5000; // fallback ONLY -- used when a stage doesn't set its own baseDurationMs. Was 3000 -- too fast to comfortably read a detailed sweep with peak markers.

// GLOBAL, not per-journey-instance -- deliberately moved out of
// interpretJourney() so every card in the scrolling feed shares this
// SAME state. Scrolling to a new card no longer resets Speed to 1.0x.
const GLOBAL_SPEED_OPTIONS = [0.5, 1.0, 1.5, 2.0];
let globalSpeedIndex = GLOBAL_SPEED_OPTIONS.indexOf(1.0);

// Real, proven SVG markup, reused directly from the old system's rail
// buttons (core/journey_feed.js) -- not redesigned from scratch. Keyed by
// the recipe's own control.ui.icon field, so a recipe can reference any
// of these by name without journey_interpreter.js needing to know which
// button label goes with which icon.
const RAIL_ICONS = {
    icon_flip_vertical: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v6M9 6l3-3 3 3"/><path d="M12 21v-6M9 18l3 3 3-3"/></svg>`,
    icon_theme: `<svg viewBox="0 0 24 24" width="20" height="20"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor"/></svg>`,
};

// Methods that CYCLE a value (as opposed to toggling a boolean or firing
// an icon-represented action) -- for these, showing the CURRENT value as
// text is clearer than any generic icon could be. Each maps to the
// matching "get" method on the same target.
const VALUE_DISPLAY_METHODS = {
    cycleSpeed: { getMethod: "getSpeed", suffix: "x" },
    switchAlgorithm: { getMethod: "getActiveAlgorithm", suffix: "" },
    switchRenderer: { getMethod: "getActiveRenderer", suffix: "" },
};

function interpretJourney(journeyJson, sampleId, chartContainer, railContainer, titleEl, captionEl, progressBarEl, descriptionEl) {
    let currentStageIndex = 0;
    const stageOutputs = {}; // stageId -> its exported output, per stageOutput.exportKey
    const dspOutputCache = new Map(); // stageIndex -> already-computed dspOutput, populated by preloadNextStage
    let autoAdvanceTimer = null;
    let autoAdvanceEndTime = null; // absolute performance.now() timestamp the current timer should fire at -- used to compute remaining time when pausing
    let autoAdvanceRemainingMs = null; // set only while paused

    // Pause is per-JOURNEY-INSTANCE (per card), unlike Speed -- pausing
    // one card shouldn't pause a DIFFERENT card you scroll to next.
    let isPaused = false;

    const sharedMemory = { ...(journeyJson.sharedPipelineMemory || {}) };
    const journeyTarget = {
        cycleSpeed() {
            // payload.options intentionally ignored now -- see the file
            // header for why speedOptions isn't recipe-configurable.
            globalSpeedIndex = (globalSpeedIndex + 1) % GLOBAL_SPEED_OPTIONS.length;
        },
        getSpeed() {
            return GLOBAL_SPEED_OPTIONS[globalSpeedIndex];
        },
        // sharedPipelineMemory (patientId, leadType, sampleRateHz, etc) --
        // journey-level context shared across every stage, exposed via the
        // SAME getParameter/setParameter verbs the dispatcher already uses
        // for dspEngine/renderingEngine. A mutable COPY, not the original
        // journeyJson object, so a setParameter call can't silently
        // mutate the source recipe itself.
        getParameter(payload) {
            return sharedMemory[payload.key];
        },
        setParameter(payload) {
            if (payload.operation === "toggle") {
                sharedMemory[payload.key] = !sharedMemory[payload.key];
            } else {
                sharedMemory[payload.key] = payload.value;
            }
        },
    };

    function getActiveTheme() {
        return journeyJson.globalThemes.themes.find(t => t.id === journeyJson.globalThemes.activeTheme);
    }

    // Honest, MINIMAL color resolution -- NOT a generic path-resolver for
    // arbitrary strings. Handles exactly this one known recipe pattern
    // (referencing the active theme's primary color) by name; anything
    // else is treated as a literal CSS color value (e.g. inactiveColor's
    // rgba() string, which needs no resolution at all).
    function resolveColor(colorSpec) {
        if (colorSpec === "globalThemes.activeTheme.palette.primary") {
            return getActiveTheme().palette.primary;
        }
        return colorSpec;
    }

    // Builds the segment row ONCE (one segment per stage) -- doesn't
    // depend on which stage is current, so this only ever needs to run
    // a single time, not on every stage transition.
    function buildProgressBar() {
        const shell = journeyJson.uiShell;
        if (!shell || !shell.showProgressBar || !progressBarEl) return;
        progressBarEl.innerHTML = "";
        journeyJson.stages.forEach(() => {
            const segment = document.createElement("div");
            segment.className = "segment";
            segment.style.background = resolveColor(shell.progressBar.inactiveColor);
            segment.innerHTML = `<div class="fill" style="background:${resolveColor(shell.progressBar.activeColor)}"></div>`;
            progressBarEl.appendChild(segment);
        });
    }

    // Called every stage transition -- marks completed/current segments
    // and sets the CURRENT segment's fill animation to actually run for
    // durationMs (reuses shorts_feed.css's existing .segment.current
    // .fill { animation-name: fillBar } rule -- only the per-stage
    // DURATION varies, set inline here, same pattern the old app used).
    function updateProgressBar(index, durationMs) {
        const shell = journeyJson.uiShell;
        if (!shell || !shell.showProgressBar || !progressBarEl) return;
        const segments = progressBarEl.querySelectorAll(".segment");
        segments.forEach((seg, i) => {
            seg.classList.toggle("completed", i < index);
            const fill = seg.querySelector(".fill");

            if (i === index) {
                // Force the fill animation to restart from 0%, even if
                // this exact segment was ALREADY .current (e.g. a
                // restart() replay of the same stage) -- just re-setting
                // animationDuration does NOT reset an already-running CSS
                // animation's progress. Standard fix: remove the class
                // that applies the animation, force a synchronous reflow
                // (reading offsetWidth), then re-add it -- this makes the
                // browser treat it as a genuinely new animation instance.
                seg.classList.remove("current");
                void fill.offsetWidth; // force reflow -- without this, the browser may batch the class removal+re-addition together and never actually restart anything
                fill.style.animationDuration = `${durationMs}ms`;
                seg.classList.add("current");
            } else {
                seg.classList.remove("current");
            }
            fill.style.animationPlayState = "running"; // reset -- a fresh stage always starts unpaused visually
        });
    }

    // Resolves ONE stage's dataSource -- either a real HTTP fetch (Stage 1,
    // the journey's actual entry point) or a previous stage's real,
    // already-computed output (Stage 2+, PREVIOUS_STAGE_PIPELINE).
    async function resolveDataSource(stageJson) {
        const ds = stageJson.dataSource;

        if (ds.mode === "HTTP_REST") {
            const raw = await fetchSignal(sampleId);
            if (!raw) return null;
            return { t: raw.signal.map((_, i) => i / raw.fs), y: raw.signal, fs: raw.fs };
        }

        if (ds.mode === "PREVIOUS_STAGE_PIPELINE") {
            const exported = stageOutputs[ds.outputKey]; // outputKey is the real lookup key (matches stageOutput.exportKey); stageId is just which stage, for error messages
            if (!exported) {
                console.error(`Journey: output "${ds.outputKey}" from stage "${ds.stageId}" isn't available yet -- has that stage run?`);
                return null;
            }
            const value = exported[ds.consumedField];
            if (value === undefined) {
                console.error(`Journey: stage "${ds.stageId}"'s export ("${ds.outputKey}") doesn't contain field "${ds.consumedField}"`);
                return null;
            }
            return value;
        }

        console.error(`Journey: unsupported dataSource.mode "${ds.mode}" -- only HTTP_REST and PREVIOUS_STAGE_PIPELINE are wired up in this proof`);
        return null;
    }

    // Runs a stage's data resolution + DSP processing WITHOUT rendering
    // anything -- used by preloadNextStage to warm dspOutputCache while a
    // different stage is still on screen.
    async function preloadStage(index) {
        if (index < 0 || index >= journeyJson.stages.length) return;
        if (dspOutputCache.has(index)) return; // already warmed, don't redo the work

        const stageJson = journeyJson.stages[index];
        const data = await resolveDataSource(stageJson);
        if (data == null) return; // silent -- preloading is a background optimization, not something that should surface errors to the user

        const dspEngine = createDspEngine(stageJson.dspEngine);
        const dspOutput = dspEngine.process(data);
        if (!dspOutput) return;

        dspOutputCache.set(index, { dspOutput, data });

        if (stageJson.stageOutput) {
            const exported = {};
            stageJson.stageOutput.exportedFields.forEach(field => {
                exported[field] = dspOutput.finalOutput[field];
            });
            stageOutputs[stageJson.stageOutput.exportKey] = exported;
        }
    }

    async function buildStage(index) {
        const stageJson = journeyJson.stages[index];

        const cached = dspOutputCache.get(index);
        const data = cached ? cached.data : await resolveDataSource(stageJson);
        if (data == null) {
            chartContainer.innerHTML = `<p style="color:#ff4d4d; padding:20px;">Could not resolve this stage's input data (check console).</p>`;
            return;
        }

        const dspEngine = createDspEngine(stageJson.dspEngine);
        const renderingEngine = createRenderingEngine(stageJson.renderingEngine);
        const context = { dspEngine, renderingEngine, journey: journeyTarget };

        dispatch({ target: "renderingEngine", method: "applyTheme", payload: getActiveTheme() }, context);

        // Computed ONCE, used for BOTH the renderer's actual animation AND
        // the auto-advance timer AND the progress bar fill -- all three
        // must agree, or you get exactly the bug caught earlier (animation
        // visually finishes while auto-advance keeps waiting).
        const actualDuration = (stageJson.baseDurationMs || STAGE_DURATION_MS) / journeyTarget.getSpeed();

        function runAndRender(precomputedOutput) {
            const dspOutput = precomputedOutput || dspEngine.process(data);
            if (!dspOutput) {
                chartContainer.innerHTML = `<p style="color:#ff4d4d; padding:20px;">This algorithm isn't implemented yet (check console for details).</p>`;
                return;
            }
            renderingEngine.render(chartContainer, dspOutput, sampleId, data.fs, actualDuration);

            if (stageJson.stageOutput) {
                const exported = {};
                stageJson.stageOutput.exportedFields.forEach(field => {
                    exported[field] = dspOutput.finalOutput[field];
                });
                stageOutputs[stageJson.stageOutput.exportKey] = exported;
            }
        }
        runAndRender(cached ? cached.dspOutput : null);

        if (titleEl) titleEl.textContent = stageJson.uiFillers.title;
        if (captionEl) captionEl.textContent = stageJson.uiFillers.caption;
        if (descriptionEl) descriptionEl.textContent = stageJson.uiFillers.description || "";
        updateProgressBar(index, actualDuration);

        railContainer.innerHTML = "";
        stageJson.railControls.forEach(control => {
            const btn = document.createElement("button");
            btn.className = "rail-btn";
            btn.title = control.ui.label;

            function refreshButtonContent() {
                const valueDisplay = VALUE_DISPLAY_METHODS[control.action.method];
                if (valueDisplay) {
                    const targetObj = context[control.action.target];
                    const currentValue = targetObj[valueDisplay.getMethod]();
                    btn.textContent = currentValue + valueDisplay.suffix;
                } else if (control.ui.icon && RAIL_ICONS[control.ui.icon]) {
                    btn.innerHTML = RAIL_ICONS[control.ui.icon];
                } else {
                    btn.textContent = control.ui.label;
                }
            }
            refreshButtonContent();

            btn.addEventListener("click", () => {
                dispatch(control.action, context);
                runAndRender();
                refreshButtonContent();

                // A rail button click restarts the sweep FRESH (via
                // runAndRender -> renderingEngine.render), regardless of
                // pause state -- renderingEngine.render() has no idea
                // isPaused even exists. Without this, isPaused silently
                // drifts out of sync with reality: the flag says "paused"
                // while the sweep is actually running again underneath,
                // breaking the NEXT pause/resume tap. The progress bar
                // fill and auto-advance timer need the same "actually
                // playing again" restart too, or THEY drift out of sync
                // as well.
                if (isPaused) {
                    isPaused = false;
                    updateProgressBar(currentStageIndex, actualDuration);
                    if (journeyJson.journeyRules.autoAdvance && currentStageIndex < journeyJson.stages.length - 1) {
                        autoAdvanceEndTime = performance.now() + actualDuration;
                        autoAdvanceTimer = setTimeout(() => goToStage(currentStageIndex + 1), actualDuration);
                    }
                }
            });
            railContainer.appendChild(btn);
        });

        if (journeyJson.journeyRules.preloadNextStage) {
            preloadStage(index + 1);
        }

        if (journeyJson.journeyRules.autoAdvance && index < journeyJson.stages.length - 1) {
            autoAdvanceEndTime = performance.now() + actualDuration;
            autoAdvanceTimer = setTimeout(() => goToStage(index + 1), actualDuration);
        }
    }

    async function goToStage(index) {
        if (index < 0 || index >= journeyJson.stages.length) return;
        if (autoAdvanceTimer) {
            clearTimeout(autoAdvanceTimer);
            autoAdvanceTimer = null;
        }
        isPaused = false; // a fresh stage always starts playing, never inherits the previous stage's paused state
        cancelSweepAnimation(sampleId);
        currentStageIndex = index;
        await buildStage(currentStageIndex);
    }

    // Pauses/resumes THREE things together, so they can't drift apart:
    // the sweep animation itself, the auto-advance timer, and the
    // progress bar's visual fill.
    function togglePause() {
        isPaused = !isPaused;

        const currentFill = progressBarEl && progressBarEl.querySelector(".segment.current .fill");

        if (isPaused) {
            // activeSweepControl still holds lastElapsedMs after
            // cancelling -- resuming continues from exactly where it
            // stopped, not from 0.
            cancelSweepAnimation(sampleId);

            if (autoAdvanceTimer) {
                clearTimeout(autoAdvanceTimer);
                autoAdvanceRemainingMs = autoAdvanceEndTime - performance.now();
                autoAdvanceTimer = null;
            }

            if (currentFill) currentFill.style.animationPlayState = "paused";
        } else {
            const control = activeSweepControl.get(sampleId);
            if (control) {
                startSweepLoop(sampleId, control.totalDurationMs, control.drawFn, control.lastElapsedMs);
            }

            if (journeyJson.journeyRules.autoAdvance && autoAdvanceRemainingMs != null) {
                autoAdvanceEndTime = performance.now() + autoAdvanceRemainingMs;
                autoAdvanceTimer = setTimeout(() => goToStage(currentStageIndex + 1), autoAdvanceRemainingMs);
                autoAdvanceRemainingMs = null;
            }

            if (currentFill) currentFill.style.animationPlayState = "running";
        }
    }

    buildProgressBar();

    return {
        async start() {
            await goToStage(0); // MUST wait for the stage to fully build (sweep started) before pausing it -- otherwise the sweep starts anyway a moment later, ignoring the pause
            if (journeyJson.playbackConfig && journeyJson.playbackConfig.isPaused) {
                togglePause();
            }
        },
        next() { if (journeyJson.journeyRules.allowStageNavigation) goToStage(currentStageIndex + 1); },
        prev() { if (journeyJson.journeyRules.allowStageNavigation) goToStage(currentStageIndex - 1); },
        restart() { goToStage(currentStageIndex); }, // replays the CURRENT stage from the beginning -- used for the "first tap restarts, fast second tap goes back" pattern
        togglePause,
    };
}