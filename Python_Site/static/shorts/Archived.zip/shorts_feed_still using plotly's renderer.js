// ---------------------------------------------------------------------------
// shorts_feed.js
// Drives the horizontal stage machine (auto-advance + tap-to-jump) inside
// each vertically-snapped card. Vertical scrolling itself needs NO JS at all
// -- that's native browser scroll-snap, per shorts_feed.css.
// ---------------------------------------------------------------------------

// Per-stage durations, in ms. Stage 0 (raw sweep) gets a bit longer since
// it's the one stage actively "drawing" rather than just revealing a
// number/badge. Verdict (last stage) never auto-advances regardless of what
// duration is listed here -- advance() already stops the timer once it
// reaches the final stage, so its duration value is unused in practice.
const STAGE_DURATIONS_MS = [2800, 2000, 2500, 2200, 2000];
const DEFAULT_STAGE_DURATION_MS = 2200; // fallback if a card has more stages than durations listed

// Global speed toggle -- "teaser" (fixed, fast, same for every card) or
// "real" (stage 0's sweep takes as long as the actual recording, which
// varies card to card since these are now true WFDB-length signals).
let playbackMode = "teaser";

// Each sample's real recording length, in ms, populated the first time its
// raw signal is fetched (see drawRawSignalStage). Needed regardless of
// which mode is active, since "real" mode has no single fixed number --
// every recording is a different length.
const recordingDurationMs = new Map();

function getStageDuration(stageIdx, sampleId) {
    if (stageIdx === 0 && playbackMode === "real" && recordingDurationMs.has(sampleId)) {
        return recordingDurationMs.get(sampleId);
    }
    return STAGE_DURATIONS_MS[stageIdx] ?? DEFAULT_STAGE_DURATION_MS;
}
const SESSION_SUMMARY_EVERY = 10; // show the "nice session" card every N cards viewed

const STORAGE_KEY = "ecg_shorts_progress";

function loadProgress() {
    try {
        return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
    } catch {
        return {};
    }
}

function saveProgress(progress) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
}

const progress = loadProgress();
let cardsViewedThisSession = 0;
let activeTimers = new Map();
const renderedCharts = new Set(); // "sampleId-stageIdx" keys already drawn, so we never re-animate a chart twice

// ---------------------------------------------------------------------------
// Stage 0 renderer: fetches the REAL raw signal for this sample from the
// pipeline (via RawSignalStore on the backend), then draws it as an
// animated left-to-right sweep -- same fetch-then-Plotly pattern already
// used in control_panel.js / plot_renderers.js.
// ---------------------------------------------------------------------------
async function drawRawSignalStage(container, sampleId) {
    const key = `${sampleId}-0`;
    if (renderedCharts.has(key)) return; // already drawn once, don't re-animate
    renderedCharts.add(key);

    container.classList.add("loading");

    let signal, fs;
    try {
        const res = await fetch(`/shorts/api/sample/${sampleId}/raw`);
        if (!res.ok) throw new Error(`Server returned ${res.status}`);
        const payload = await res.json();
        signal = payload.signal;
        fs = payload.fs;
    } catch (err) {
        console.error(`Failed to load raw signal for ${sampleId}:`, err);
        renderedCharts.delete(key); // allow a retry if the user revisits this card
        container.classList.remove("loading");
        return;
    }

    const y = signal;
    const t = y.map((_, i) => i / fs);
    const yMin = Math.min(...y) - 0.1;
    const yMax = Math.max(...y) + 0.1;

    // real duration of this specific recording, stored BEFORE getStageDuration
    // is called below, so a redraw triggered by the toggle (or a first draw
    // while already in "real" mode) picks up the correct value immediately
    recordingDurationMs.set(sampleId, Math.round((y.length / fs) * 1000));

    // Fixed-width scrolling window, in real ECG seconds -- NOT the whole
    // recording. Solves the "crowding" problem: a 30-90s recording no longer
    // ends up with every beat overlapping on screen at once. A window this
    // wide typically shows 4-6 beats at a time, similar to a bedside monitor.
    const ECG_WINDOW_SECONDS = 5;
    const windowSamples = Math.round(ECG_WINDOW_SECONDS * fs);

    const trace = {
        x: [t[0]],
        y: [y[0]],
        mode: "lines",
        line: { color: "#5cc24a", width: 2, shape: "spline" },
        hoverinfo: "skip",
    };

    const layout = {
        margin: { t: 10, r: 10, b: 10, l: 10 },
        paper_bgcolor: "transparent",
        plot_bgcolor: "transparent",
        // starts showing a stationary window that fills left-to-right;
        // once full, frames below slide this range forward instead of
        // widening it -- see startIdx logic in the frame loop
        xaxis: { visible: false, range: [t[0], t[0] + ECG_WINDOW_SECONDS] },
        yaxis: { visible: false, range: [yMin, yMax] },
        showlegend: false,
    };

    Plotly.newPlot(container, [trace], layout, { staticPlot: true, responsive: true });
    container.classList.remove("loading");

    // Downsamples a window's worth of points down to a fixed maximum, via
    // simple stride sampling (every Nth point). A line chart only needs a
    // few hundred points to look smooth -- feeding Plotly the full ~1500
    // raw samples in a 5s window, on EVERY animation frame, is far more
    // redraw work than the visual result needs, and is the likely source
    // of the lag noticed earlier. This trades a little precision (fine for
    // a raw-signal preview) for meaningfully cheaper, smoother redraws.
    const MAX_POINTS_PER_FRAME = 200;

    function downsample(xArr, yArr, maxPoints) {
        const n = xArr.length;
        if (n <= maxPoints) return { x: xArr, y: yArr };

        const strideStep = Math.ceil(n / maxPoints);
        const dsX = [], dsY = [];
        for (let idx = 0; idx < n; idx += strideStep) {
            dsX.push(xArr[idx]);
            dsY.push(yArr[idx]);
        }
        // always keep the true last point, so the line's leading edge
        // never lags behind where the sweep actually is
        const lastIdx = n - 1;
        if (dsX[dsX.length - 1] !== xArr[lastIdx]) {
            dsX.push(xArr[lastIdx]);
            dsY.push(yArr[lastIdx]);
        }
        return { x: dsX, y: dsY };
    }

    // build one animation frame every few samples (not every single sample --
    // that's far more Plotly.animate calls than needed and would feel choppy
    // due to overhead, not smoother)
    const framesWanted = 90; // ~how many animation steps across the whole draw
    const step = Math.max(1, Math.floor(t.length / framesWanted));
    const frames = [];

    for (let i = step; i < t.length; i += step) {
        // trailing window only -- everything older than ECG_WINDOW_SECONDS
        // behind the current point is dropped from what's drawn, not just
        // scrolled out of view, so old beats don't pile up in memory either
        const startIdx = Math.max(0, i - windowSamples);

        // Phase 1 (still filling the first window): range stays fixed at
        // [t[0], t[0]+ECG_WINDOW_SECONDS], trace just grows left to right.
        // Phase 2 (window is full): range SLIDES forward with the data,
        // always spanning exactly ECG_WINDOW_SECONDS.
        const rangeStart = startIdx === 0 ? t[0] : t[startIdx];
        const rangeEnd = startIdx === 0 ? t[0] + ECG_WINDOW_SECONDS : t[i - 1];

        const { x: frameX, y: frameY } = downsample(
            t.slice(startIdx, i), y.slice(startIdx, i), MAX_POINTS_PER_FRAME
        );

        frames.push({
            name: `f${i}`,
            data: [{ x: frameX, y: frameY }],
            layout: { xaxis: { visible: false, range: [rangeStart, rangeEnd] } },
        });
    }

    // final frame: still just the trailing window, NOT the whole signal --
    // otherwise the last frame would zoom back out and re-crowd the screen
    const finalStart = Math.max(0, t.length - windowSamples);
    const { x: finalX, y: finalY } = downsample(
        t.slice(finalStart), y.slice(finalStart), MAX_POINTS_PER_FRAME
    );
    frames.push({
        name: "final",
        data: [{ x: finalX, y: finalY }],
        layout: { xaxis: { visible: false, range: [t[finalStart], t[t.length - 1]] } },
    });

    Plotly.addFrames(container, frames);
    Plotly.animate(container, frames.map(f => f.name), {
        frame: { duration: getStageDuration(0, sampleId) / frames.length, redraw: false },
        transition: { duration: 0 },
        mode: "immediate",
    });
}

function renderStageChart(sampleId, stageIdx, container) {
    switch (stageIdx) {
        case 0:
            drawRawSignalStage(container, sampleId);
            break;
        // case 1, 2, 3, 4 -- corrected signal, peaks, metrics, verdict --
        // still to be built.
        default:
            break;
    }
}

// ---------------------------------------------------------------------------
// Dynamic card construction. Builds the same DOM structure the static demo
// cards used to have, but from a real sample_id fetched from the backend.
// stageCount defaults to 5 (raw -> corrected -> peaks -> metrics -> verdict);
// only stage 0 actually renders anything real right now -- 1-4 stay empty
// placeholders until those renderers exist.
// ---------------------------------------------------------------------------
function buildCardElement(sampleId, label, stageCount = 5) {
    const stageNames = ["Raw signal", "Corrected", "Peak detection", "HRV metrics", "Verdict"];

    const card = document.createElement("section");
    card.className = "card";
    card.dataset.sampleId = sampleId;
    card.dataset.trueLabel = label ?? ""; // stored for later use -- rarity framing,
                                            // guess-before-reveal, verdict stage.
                                            // Not displayed anywhere yet.

    const bar = document.createElement("div");
    bar.className = "stage-bar";
    bar.dataset.stageCount = stageCount;

    const viewport = document.createElement("div");
    viewport.className = "stage-viewport";

    for (let i = 0; i < stageCount; i++) {
        const segment = document.createElement("div");
        segment.className = "segment";
        segment.dataset.stage = i;
        segment.innerHTML = '<div class="fill"></div>';
        bar.appendChild(segment);

        const stageContent = document.createElement("div");
        stageContent.className = i === 0 ? "stage-content active" : "stage-content";
        stageContent.dataset.stage = i;
        stageContent.innerHTML = `
            <div class="stage-label${i === stageCount - 1 ? " verdict-label" : ""}">${stageNames[i] || `Stage ${i}`}</div>
            <div class="chart-frame${i === stageCount - 1 ? " verdict-frame" : ""}" id="chart-${sampleId}-${i}"></div>
        `;
        viewport.appendChild(stageContent);
    }

    const footer = document.createElement("div");
    footer.className = "card-footer";
    footer.innerHTML = `
        <span class="sample-id">#${sampleId}</span>
        <span class="tap-hint">tap right to advance &middot; swipe up for next</span>
    `;

    card.appendChild(bar);
    card.appendChild(viewport);
    card.appendChild(footer);
    return card;
}

// Fetches real record IDs and populates the feed before anything else runs.
async function loadFeedCards(limit = 10) {
    const feed = document.getElementById("feed");
    try {
        const res = await fetch(`/shorts/api/samples?limit=${limit}`);
        if (!res.ok) throw new Error(`Server returned ${res.status}`);
        const { samples } = await res.json();

        if (samples.length === 0) {
            feed.innerHTML = '<p style="color:#747d8c;text-align:center;margin-top:40vh;">No records found in cache.</p>';
            return;
        }

        samples.forEach(({ record_id, label }) => feed.appendChild(buildCardElement(record_id, label)));
    } catch (err) {
        console.error("Failed to load sample list:", err);
        feed.innerHTML = '<p style="color:#a32638;text-align:center;margin-top:40vh;">Could not load records.</p>';
    }
}

// ---------------------------------------------------------------------------
// Per-card stage controller
// ---------------------------------------------------------------------------
function initCard(cardEl) {
    const sampleId = cardEl.dataset.sampleId;
    const bar = cardEl.querySelector(".stage-bar");
    const segments = Array.from(bar.querySelectorAll(".segment"));
    const stageEls = Array.from(cardEl.querySelectorAll(".stage-content"));
    const maxStage = stageEls.length - 1;

    let currentStage = progress[sampleId]?.stage ?? 0;
    currentStage = Math.min(currentStage, maxStage);

    function showStage(stageIdx, options) {
        const animate = !(options && options.animate === false);
        currentStage = stageIdx;

        stageEls.forEach(el => {
            const isActive = Number(el.dataset.stage) === stageIdx;
            el.classList.toggle("active", isActive);
            if (isActive) {
                const container = el.querySelector(".chart-frame");
                if (container) renderStageChart(sampleId, stageIdx, container);
            }
        });

        segments.forEach((seg, i) => {
            seg.classList.remove("completed", "current");
            const fill = seg.querySelector(".fill");
            if (i < stageIdx) {
                seg.classList.add("completed");
            } else if (i === stageIdx) {
                seg.classList.add("current");
                fill.style.animationDuration = `${getStageDuration(stageIdx, sampleId)}ms`; // matches this stage's real timing
            }
        });

        progress[sampleId] = { stage: stageIdx, seenAt: Date.now() };
        saveProgress(progress);
    }

    function advance() {
        if (currentStage < maxStage) {
            showStage(currentStage + 1);
            scheduleNextAdvance(); // each stage re-schedules using ITS OWN duration
        } else {
            clearAutoAdvance(sampleId); // reached the verdict -- hold, no further advancing
        }
    }

    function scheduleNextAdvance() {
        clearAutoAdvance(sampleId); // never let two timers stack for the same card
        const handle = setTimeout(advance, getStageDuration(currentStage, sampleId));
        activeTimers.set(sampleId, handle);
    }

    function startAutoAdvance() {
        scheduleNextAdvance(); // begins the chain from whatever stage we're currently on
    }

    segments.forEach((seg, i) => {
        seg.addEventListener("click", () => {
            showStage(i);
            startAutoAdvance();
        });
    });

    const viewport = cardEl.querySelector(".stage-viewport");
    viewport.addEventListener("click", (e) => {
        const rect = viewport.getBoundingClientRect();
        const tappedRight = (e.clientX - rect.left) > rect.width / 2;
        if (tappedRight) {
            advance();
        } else if (currentStage > 0) {
            showStage(currentStage - 1);
        }
        startAutoAdvance();
    });

    showStage(currentStage, { animate: false });

    // Called by the global speed toggle when its mode flips -- if this card
    // is currently showing stage 0, re-draw it immediately (using whichever
    // duration now applies) and reschedule the auto-advance timer to match.
    // Cards NOT on stage 0 right now just pick up the new mode naturally the
    // next time their stage 0 becomes active (no action needed for those).
    function refreshStage0IfActive() {
        if (currentStage !== 0) return;
        const stage0El = stageEls.find(el => Number(el.dataset.stage) === 0);
        const container = stage0El && stage0El.querySelector(".chart-frame");
        if (!container) return;

        renderedCharts.delete(`${sampleId}-0`); // allow drawRawSignalStage to run again
        renderStageChart(sampleId, 0, container);

        const fill = segments[0].querySelector(".fill");
        fill.style.animationDuration = `${getStageDuration(0, sampleId)}ms`;

        startAutoAdvance(); // re-schedule using the new duration
    }

    return { startAutoAdvance, sampleId, refreshStage0IfActive };
}

function clearAutoAdvance(sampleId) {
    if (activeTimers.has(sampleId)) {
        clearTimeout(activeTimers.get(sampleId)); // setTimeout now, not setInterval -- see advance()/scheduleNextAdvance()
        activeTimers.delete(sampleId);
    }
}

let currentlyVisibleController = null; // updated by initFeed's observer below

function initFeed() {
    const cards = Array.from(document.querySelectorAll(".card"));
    const controllers = new Map(cards.map(card => [card, initCard(card)]));

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            const controller = controllers.get(entry.target);
            if (!controller) return;
            if (entry.isIntersecting) {
                controller.startAutoAdvance();
                currentlyVisibleController = controller;
                onCardEntered(entry.target);
            } else {
                clearAutoAdvance(controller.sampleId);
            }
        });
    }, { threshold: 0.6 });

    cards.forEach(card => observer.observe(card));
}

const seenThisSession = new Set();

function onCardEntered(cardEl) {
    const sampleId = cardEl.dataset.sampleId;
    if (seenThisSession.has(sampleId)) return;
    seenThisSession.add(sampleId);
    cardsViewedThisSession++;
    if (cardsViewedThisSession % SESSION_SUMMARY_EVERY === 0) {
        showSessionSummary();
    }
}

function showSessionSummary() {
    const overlay = document.getElementById("session-summary");
    document.getElementById("summary-count").textContent = cardsViewedThisSession;
    overlay.classList.remove("hidden");
}

document.addEventListener("DOMContentLoaded", async () => {
    await loadFeedCards(); // build real cards first...
    initFeed();             // ...then wire up stage machinery + scroll watching

    const dismissBtn = document.getElementById("summary-dismiss");
    if (dismissBtn) {
        dismissBtn.addEventListener("click", () => {
            document.getElementById("session-summary").classList.add("hidden");
        });
    }

    const speedToggle = document.getElementById("speed-toggle");
    if (speedToggle) {
        speedToggle.addEventListener("click", () => {
            playbackMode = playbackMode === "teaser" ? "real" : "teaser";
            speedToggle.textContent = playbackMode === "teaser" ? "⚡ Fast preview" : "🕐 Real-time";
            speedToggle.setAttribute("aria-pressed", playbackMode === "real");
            if (currentlyVisibleController) {
                currentlyVisibleController.refreshStage0IfActive();
            }
        });
    }
});