// ---------------------------------------------------------------------------
// shorts_feed.js
// Drives the horizontal stage machine (auto-advance + tap-to-jump) inside
// each vertically-snapped card. Vertical scrolling itself needs NO JS at all
// -- that's native browser scroll-snap, per shorts_feed.css.
// ---------------------------------------------------------------------------

const STAGE_DURATION_MS = 2200; // per-stage auto-advance timing
const SESSION_SUMMARY_EVERY = 10; // show the "nice session" card every N cards viewed

const STORAGE_KEY = "ecg_shorts_progress";

function loadProgress() {
    try {
        return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
    } catch {
        return {};
    }
}

function saveProgress(progress) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
}

const progress = loadProgress();
let cardsViewedThisSession = 0;
let activeTimers = new Map();
const renderedCharts = new Set(); // "sampleId-stageIdx" keys already drawn, so we never re-animate a chart twice

// ---------------------------------------------------------------------------
// Synthetic ECG generator -- placeholder until real sample data flows in
// from a backend. Produces a plausible-looking PQRST waveform so we have
// something real to animate and style.
// ---------------------------------------------------------------------------
function generateSyntheticEcg(seedString, durationSeconds = 6, fs = 250) {
    // simple string hash so the same sampleId always produces the same "signal"
    let seed = 0;
    for (let i = 0; i < seedString.length; i++) seed = (seed * 31 + seedString.charCodeAt(i)) % 100000;
    const rand = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };

    const n = durationSeconds * fs;
    const beatIntervalSamples = Math.round(fs * (0.7 + rand() * 0.3)); // ~70-100 bpm
    const t = new Array(n);
    const y = new Array(n);

    function gaussian(x, center, width, height) {
        return height * Math.exp(-((x - center) ** 2) / (2 * width * width));
    }

    for (let i = 0; i < n; i++) {
        t[i] = i / fs;
        const phase = i % beatIntervalSamples;
        let v = 0;
        v += gaussian(phase, beatIntervalSamples * 0.18, 8, 0.15);   // P wave
        v += gaussian(phase, beatIntervalSamples * 0.30, 3, -0.1);   // Q dip
        v += gaussian(phase, beatIntervalSamples * 0.32, 2, 1.2);    // R spike
        v += gaussian(phase, beatIntervalSamples * 0.34, 3, -0.25);  // S dip
        v += gaussian(phase, beatIntervalSamples * 0.55, 12, 0.25);  // T wave
        v += (rand() - 0.5) * 0.03; // small noise
        y[i] = v;
    }
    return { t, y };
}

// ---------------------------------------------------------------------------
// Stage 0 renderer: animated left-to-right draw of the raw signal.
// ---------------------------------------------------------------------------
function drawRawSignalStage(container, sampleId) {
    const key = `${sampleId}-0`;
    if (renderedCharts.has(key)) return; // already drawn once, don't re-animate
    renderedCharts.add(key);

    const { t, y } = generateSyntheticEcg(sampleId);
    const yMin = Math.min(...y) - 0.1;
    const yMax = Math.max(...y) + 0.1;

    const trace = {
        x: [t[0]],
        y: [y[0]],
        mode: "lines",
        line: { color: "#5cc24a", width: 2, shape: "spline" },
        hoverinfo: "skip",
    };

    const layout = {
        margin: { t: 10, r: 10, b: 10, l: 10 },
        paper_bgcolor: "transparent",
        plot_bgcolor: "transparent",
        xaxis: { visible: false, range: [t[0], t[t.length - 1]] }, // fixed range -- no rescale jumps as data streams in
        yaxis: { visible: false, range: [yMin, yMax] },
        showlegend: false,
    };

    Plotly.newPlot(container, [trace], layout, { staticPlot: true, responsive: true });

    // build one animation frame every few samples (not every single sample --
    // that's far more Plotly.animate calls than needed and would feel choppy
    // due to overhead, not smoother)
    const framesWanted = 90; // ~how many animation steps across the whole draw
    const step = Math.max(1, Math.floor(t.length / framesWanted));
    const frames = [];
    for (let i = step; i < t.length; i += step) {
        frames.push({
            name: `f${i}`,
            data: [{ x: t.slice(0, i), y: y.slice(0, i) }],
        });
    }
    frames.push({ name: "final", data: [{ x: t, y: y }] }); // ensure it always ends fully drawn

    Plotly.addFrames(container, frames);
    Plotly.animate(container, frames.map(f => f.name), {
        frame: { duration: STAGE_DURATION_MS / frames.length, redraw: false },
        transition: { duration: 0 },
        mode: "immediate",
    });
}

function renderStageChart(sampleId, stageIdx, container) {
    switch (stageIdx) {
        case 0:
            drawRawSignalStage(container, sampleId);
            break;
        // case 1, 2, 3, 4 -- corrected signal, peaks, metrics, verdict --
        // still to be built.
        default:
            break;
    }
}

// ---------------------------------------------------------------------------
// Per-card stage controller
// ---------------------------------------------------------------------------
function initCard(cardEl) {
    const sampleId = cardEl.dataset.sampleId;
    const bar = cardEl.querySelector(".stage-bar");
    const segments = Array.from(bar.querySelectorAll(".segment"));
    const stageEls = Array.from(cardEl.querySelectorAll(".stage-content"));
    const maxStage = stageEls.length - 1;

    let currentStage = progress[sampleId]?.stage ?? 0;
    currentStage = Math.min(currentStage, maxStage);

    function showStage(stageIdx, options) {
        const animate = !(options && options.animate === false);
        currentStage = stageIdx;

        stageEls.forEach(el => {
            const isActive = Number(el.dataset.stage) === stageIdx;
            el.classList.toggle("active", isActive);
            if (isActive) {
                const container = el.querySelector(".chart-frame");
                if (container) renderStageChart(sampleId, stageIdx, container);
            }
        });

        segments.forEach((seg, i) => {
            seg.classList.remove("completed", "current");
            if (i < stageIdx) {
                seg.classList.add("completed");
            } else if (i === stageIdx) {
                seg.classList.add("current");
            }
        });

        progress[sampleId] = { stage: stageIdx, seenAt: Date.now() };
        saveProgress(progress);
    }

    function advance() {
        if (currentStage < maxStage) {
            showStage(currentStage + 1);
        } else {
            clearAutoAdvance(sampleId);
        }
    }

    function startAutoAdvance() {
        clearAutoAdvance(sampleId);
        const handle = setInterval(advance, STAGE_DURATION_MS);
        activeTimers.set(sampleId, handle);
    }

    segments.forEach((seg, i) => {
        seg.addEventListener("click", () => {
            showStage(i);
            startAutoAdvance();
        });
    });

    const viewport = cardEl.querySelector(".stage-viewport");
    viewport.addEventListener("click", (e) => {
        const rect = viewport.getBoundingClientRect();
        const tappedRight = (e.clientX - rect.left) > rect.width / 2;
        if (tappedRight) {
            advance();
        } else if (currentStage > 0) {
            showStage(currentStage - 1);
        }
        startAutoAdvance();
    });

    showStage(currentStage, { animate: false });

    return { startAutoAdvance, sampleId };
}

function clearAutoAdvance(sampleId) {
    if (activeTimers.has(sampleId)) {
        clearInterval(activeTimers.get(sampleId));
        activeTimers.delete(sampleId);
    }
}

function initFeed() {
    const cards = Array.from(document.querySelectorAll(".card"));
    const controllers = new Map(cards.map(card => [card, initCard(card)]));

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            const controller = controllers.get(entry.target);
            if (!controller) return;
            if (entry.isIntersecting) {
                controller.startAutoAdvance();
                onCardEntered(entry.target);
            } else {
                clearAutoAdvance(controller.sampleId);
            }
        });
    }, { threshold: 0.6 });

    cards.forEach(card => observer.observe(card));
}

const seenThisSession = new Set();

function onCardEntered(cardEl) {
    const sampleId = cardEl.dataset.sampleId;
    if (seenThisSession.has(sampleId)) return;
    seenThisSession.add(sampleId);
    cardsViewedThisSession++;
    if (cardsViewedThisSession % SESSION_SUMMARY_EVERY === 0) {
        showSessionSummary();
    }
}

function showSessionSummary() {
    const overlay = document.getElementById("session-summary");
    document.getElementById("summary-count").textContent = cardsViewedThisSession;
    overlay.classList.remove("hidden");
}

document.addEventListener("DOMContentLoaded", () => {
    initFeed();
    const dismissBtn = document.getElementById("summary-dismiss");
    if (dismissBtn) {
        dismissBtn.addEventListener("click", () => {
            document.getElementById("session-summary").classList.add("hidden");
        });
    }
});
